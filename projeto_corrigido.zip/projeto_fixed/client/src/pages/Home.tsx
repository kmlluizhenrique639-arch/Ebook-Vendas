import { Button } from "@/components/ui/button";
import { Check, Zap, BookOpen, Code2, Smartphone, TrendingUp, Users, Award } from "lucide-react";
import { useState } from "react";

/**
 * Landing Page para o Ebook "O Código da IA"
 * Design: Moderno, inovador com paleta azul/branco/preto
 * Objetivo: Converter visitantes em compradores do ebook
 */

export default function Home() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubmitted(true);
      setTimeout(() => {
        setEmail("");
        setSubmitted(false);
      }, 3000);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center">
              <Code2 className="w-6 h-6 text-white" />
            </div>
            <span className="font-bold text-xl text-gray-900">O Código da IA</span>
          </div>
          <div className="hidden md:flex gap-8 items-center">
            <a href="#beneficios" className="text-gray-600 hover:text-blue-600 transition">Benefícios</a>
            <a href="#conteudo" className="text-gray-600 hover:text-blue-600 transition">Conteúdo</a>
            <a href="#cta" className="text-gray-600 hover:text-blue-600 transition">Comprar</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-20 pb-32 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-block bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-semibold">
                ✨ Transforme sua vida financeira com IA
              </div>
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900 leading-tight">
                Ganhe Dinheiro com Inteligência Artificial do Zero
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Descubra as 20 estratégias mais lucrativas para criar renda extra online usando IA. Mesmo sem experiência prévia, você pode começar hoje.
              </p>
            </div>

            {/* Key Stats */}
            <div className="grid grid-cols-3 gap-4 pt-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">20+</div>
                <p className="text-sm text-gray-600">Capítulos Práticos</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">70</div>
                <p className="text-sm text-gray-600">Páginas Completas</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">∞</div>
                <p className="text-sm text-gray-600">Possibilidades</p>
              </div>
            </div>

            {/* CTA Button */}
            <div className="pt-4">
              <Button 
                size="lg" 
                className="bg-blue-600 hover:bg-blue-700 text-white text-lg h-14 px-8 rounded-lg font-semibold transition-all transform hover:scale-105"
                onClick={() => document.getElementById('cta')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Quero Começar Agora →
              </Button>
              <p className="text-sm text-gray-600 mt-3">Acesso imediato após a compra</p>
            </div>
          </div>

          {/* Right Image */}
          <div className="relative h-96 md:h-full">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl overflow-hidden">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663390224589/dkSFuJEZtHA98Lq2qXR2Hh/hero-ia-renda-V9Q9tCK7j32Zkcqn8VjrZZ.webp" 
                alt="IA e Ganhos Financeiros" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Problem & Solution Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 text-gray-900">
            Você Enfrenta Esses Problemas?
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-xl border border-gray-200">
              <div className="text-3xl mb-4">😰</div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Falta de Renda Extra</h3>
              <p className="text-gray-600">Seu salário não é suficiente e você não sabe como gerar renda adicional de forma segura.</p>
            </div>
            <div className="bg-white p-8 rounded-xl border border-gray-200">
              <div className="text-3xl mb-4">🤔</div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Desconhecimento de IA</h3>
              <p className="text-gray-600">Ouve falar sobre IA mas não sabe por onde começar ou como aplicar na prática.</p>
            </div>
            <div className="bg-white p-8 rounded-xl border border-gray-200">
              <div className="text-3xl mb-4">⏰</div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Falta de Tempo</h3>
              <p className="text-gray-600">Trabalha o dia todo e não tem tempo para aprender novas habilidades.</p>
            </div>
            <div className="bg-white p-8 rounded-xl border border-gray-200">
              <div className="text-3xl mb-4">💸</div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Investimento Inicial Alto</h3>
              <p className="text-gray-600">Acredita que precisa de muito dinheiro para começar um negócio online.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="beneficios" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-4 text-gray-900">
            O Que Você Vai Aprender
          </h2>
          <p className="text-center text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
            Nosso ebook foi estruturado para levar você do zero à renda sustentável em poucas semanas.
          </p>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              { icon: Zap, title: "Escrita com IA", desc: "Crie conteúdo viral e persuasivo em minutos" },
              { icon: Smartphone, title: "Redes Sociais", desc: "Automatize postagens e aumente seu alcance" },
              { icon: BookOpen, title: "Produtos Digitais", desc: "Venda cursos e ebooks com alta margem" },
              { icon: TrendingUp, title: "SEO & Blogs", desc: "Ganhe dinheiro com tráfego orgânico" },
              { icon: Users, title: "Freelancer 10X", desc: "Multiplique seus ganhos como freelancer" },
              { icon: Award, title: "Consultoria IA", desc: "Ofereça serviços premium a empresas" },
            ].map((item, i) => (
              <div key={i} className="bg-white p-8 rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-lg transition">
                <item.icon className="w-10 h-10 text-blue-600 mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Content Preview Section */}
      <section id="conteudo" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 text-gray-900">
            20 Capítulos Práticos & Aplicáveis
          </h2>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              "Desmistificando a IA",
              "Escrita e Copywriting",
              "Redes Sociais",
              "Arte e Design Digital",
              "SEO e Blogs",
              "Marketing de Afiliados",
              "Produtos Digitais",
              "Freelancer do Futuro",
              "Vídeos Sem Aparecer",
              "Tradução Global",
              "Sites e Landing Pages",
              "Chatbots Inteligentes",
              "Email Marketing",
              "Tráfego Pago",
              "Consultoria de IA",
              "Escalando Ganhos",
              "Automação Avançada",
              "Ferramentas Essenciais",
              "Plano de Ação",
              "Próximos Passos"
            ].map((chapter, i) => (
              <div key={i} className="bg-white p-6 rounded-lg border border-gray-200 flex items-start gap-4">
                <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold text-sm">
                  {i + 1}
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{chapter}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 text-gray-900">
            Por Que Este Ebook?
          </h2>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              {[
                "Estruturado para iniciantes - sem jargão técnico",
                "Exemplos práticos e ferramentas reais",
                "Atividades para aplicar imediatamente",
                "Estratégias testadas e comprovadas",
                "Atualizado com as últimas tendências de IA",
                "Suporte contínuo e comunidade exclusiva"
              ].map((feature, i) => (
                <div key={i} className="flex gap-4 items-start">
                  <Check className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                  <p className="text-lg text-gray-700">{feature}</p>
                </div>
              ))}
            </div>

            <div className="relative h-96">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl overflow-hidden">
                <img 
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663390224589/dkSFuJEZtHA98Lq2qXR2Hh/ia-tools-dashboard-n3N7ZoUXUQ8JRxWHJg2mCQ.webp" 
                  alt="Dashboard de Ferramentas IA" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-900 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-12">Resultados Reais</h2>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div>
              <div className="text-4xl font-bold text-blue-400 mb-2">5000+</div>
              <p className="text-gray-300">Leitores Satisfeitos</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-blue-400 mb-2">R$ 50M+</div>
              <p className="text-gray-300">Gerados pelos Leitores</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-blue-400 mb-2">4.9★</div>
              <p className="text-gray-300">Avaliação Média</p>
            </div>
          </div>

          <div className="bg-gray-800 p-8 rounded-xl border border-gray-700">
            <p className="text-xl italic text-gray-300 mb-4">
              "Este ebook mudou completamente minha vida. Em 3 meses, já estava ganhando R$ 5.000 por mês com as estratégias ensinadas. Recomendo demais!"
            </p>
            <p className="font-semibold">- João Silva, Desenvolvedor</p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="cta" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-600 to-blue-800">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Pronto para Transformar Sua Vida?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Acesso imediato ao ebook completo com 70 páginas, 20 capítulos práticos e ferramentas exclusivas.
          </p>

          <form onSubmit={handleSubmit} className="bg-white p-8 rounded-xl shadow-2xl space-y-4">
            <div>
              <input
                type="email"
                placeholder="seu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
            <Button
              type="submit"
              size="lg"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white text-lg h-14 font-semibold"
            >
              {submitted ? "✓ Email Enviado!" : "Comprar Agora - R$ 97"}
            </Button>
            <p className="text-sm text-gray-600">
              Garantia de 7 dias de reembolso. Sem risco.
            </p>
          </form>

          <div className="mt-8 flex justify-center gap-8 text-white text-sm">
            <div className="flex items-center gap-2">
              <Check className="w-5 h-5" />
              Acesso Imediato
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-5 h-5" />
              Suporte Vitalício
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-5 h-5" />
              Atualizações Grátis
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="text-white font-bold mb-4">O Código da IA</h4>
              <p className="text-sm">Transformando vidas através da inteligência artificial.</p>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Links Rápidos</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">Sobre</a></li>
                <li><a href="#" className="hover:text-white transition">Contato</a></li>
                <li><a href="#" className="hover:text-white transition">Blog</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Recursos</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">FAQ</a></li>
                <li><a href="#" className="hover:text-white transition">Documentação</a></li>
                <li><a href="#" className="hover:text-white transition">Comunidade</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">Privacidade</a></li>
                <li><a href="#" className="hover:text-white transition">Termos</a></li>
                <li><a href="#" className="hover:text-white transition">Cookies</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm">
            <p>&copy; 2026 O Código da IA. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
